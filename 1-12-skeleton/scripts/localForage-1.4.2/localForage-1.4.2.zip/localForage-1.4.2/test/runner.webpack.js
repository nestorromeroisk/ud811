// if (typeof Promise === 'undefined') {
//     require('../bower_components/es6-promise/promise');
// }
// require localforage as defined in package.json
window.localforage = require('../');
// require('script!../'); // optionally use webpack/script-loader
